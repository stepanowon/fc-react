import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const ContactActionCreator = {
  asyncSearchContacts: createAsyncThunk("searchContacts", async({ name }, thunkAPI)=> {
    let url = "https://contactsvc.bmaster.kro.kr/contacts_long/search/" + name;
    const response = await axios.get(url);
    return { contacts : response.data };
  })
}