import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import { TodoReducer } from "./TodoReducer";
import { TimeReducer } from "./TimeReducer";

const RootReducer = combineReducers({
  home: TimeReducer,
  todos: TodoReducer,
});

const AppStore = configureStore({ 
  reducer: RootReducer,
  middleware: (getDefaultMiddleware) => {
    return getDefaultMiddleware({ serializableCheck: false });
  },
  devTools: process.env.NODE_ENV !== "production"
});

export default AppStore;
