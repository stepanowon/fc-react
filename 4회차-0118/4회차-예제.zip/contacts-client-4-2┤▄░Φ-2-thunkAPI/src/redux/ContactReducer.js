import { createReducer } from "@reduxjs/toolkit";
import { ContactActionCreator } from "./ContactActionCreator";

const initialState = {
  contacts: [],
  isLoading: false,
  status: "",
};

export const ContactReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(ContactActionCreator.asyncSearchContacts.pending, (state, action) => {
      state.contacts = [];
      state.isLoading = true;
      state.status = `조회중 (name: ${action.meta.arg.name})`;
    })
    .addCase(ContactActionCreator.asyncSearchContacts.fulfilled, (state, action) => {
      state.contacts = action.payload.contacts;
      state.isLoading = false;
      state.status = "조회 완료";
    })
    .addCase(ContactActionCreator.asyncSearchContacts.rejected, (state, action) => {
      state.contacts = [];
      state.isLoading = true;
      state.status = "조회 실패 : " + action.payload.status;
    });
});
