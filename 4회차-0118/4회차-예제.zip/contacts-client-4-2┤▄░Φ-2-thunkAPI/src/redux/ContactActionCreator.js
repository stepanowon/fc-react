import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const ContactActionCreator = {
  asyncSearchContacts: createAsyncThunk("searchContacts", async({ name }, thunkAPI)=> {
    try {
      thunkAPI.dispatch({ type: "additionalAction", payload: { msg:"추가적인 액션" }});
      let url = "https://contactsvc.bmaster.kro.kr/contacts_long/search/" + name;
      const response = await axios.get(url);
      return { contacts : response.data };
    } catch(e) {
      return thunkAPI.rejectWithValue({ status: e.message })
    }
  })
}