import { configureStore } from "@reduxjs/toolkit";
import { ContactReducer } from "./ContactReducer";

const logger = (store) => (next) => (action) => {
  console.log("## 전달된 action : ", action);
  //console.log("## 변경전 state : ", store.getState());
  next(action);
  //console.log("## 변경후 state : ", store.getState());
};

const ContactStore = configureStore({ 
    reducer: ContactReducer,
    middleware: (getDefaultMiddleware) => {
        return getDefaultMiddleware().concat(logger);
    },
    devTools : process.env.NODE_ENV !== "production" 
});

export default ContactStore;
