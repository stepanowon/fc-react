import { configureStore } from "@reduxjs/toolkit";
import { ContactReducer } from "./ContactReducer";

const logger = (store) => (next) => (action) => {
  console.log("## 전달된 action : ", action);
  next(action);
};

const ContactStore = configureStore({ 
    reducer: ContactReducer,
    middleware: (getDefaultMiddleware) => {
        return getDefaultMiddleware().concat(logger);
    }
});

export default ContactStore;
