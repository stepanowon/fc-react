import { createReducer } from "@reduxjs/toolkit";
import { TimeActionCreator } from "./TimeActionCreator";

const initialState = {
  currentTime: new Date(),
};

export const TimeReducer = createReducer(initialState, (builder)=>{
  builder
    .addCase(TimeActionCreator.changeTime, (state,action)=>{
      state.currentTime = action.payload.currentTime;
    })
})

