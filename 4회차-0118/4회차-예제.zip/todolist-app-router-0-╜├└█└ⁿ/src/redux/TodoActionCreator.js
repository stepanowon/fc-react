import { createAction } from "@reduxjs/toolkit";

export const TodoActionCreator = {
  addTodo: createAction("addTodo"),
  deleteTodo: createAction("deleteTodo"),
  toggleDone: createAction("toggleDone"),
  updateTodo: createAction("updateTodo"),
};