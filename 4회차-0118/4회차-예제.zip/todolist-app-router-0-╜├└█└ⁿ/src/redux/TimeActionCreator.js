import { createAction } from "@reduxjs/toolkit";

export const TimeActionCreator = {
  changeTime : createAction("changeTime"),
};

