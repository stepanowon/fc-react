import MyTime from "./MyTime";
import { TimeActionCreator } from "../redux/TimeActionCreator";
import { useDispatch, useSelector } from "react-redux";

const Home = ({ currentTime, changeTime }) => {
  return (
    <div className="card card-body">
      <h2>Home</h2>
      <MyTime currentTime={currentTime} changeTime={changeTime} />
    </div>
  );
};

export const HomeContainer = () => {
  const dispatch = useDispatch();
  const currentTime = useSelector((state)=>state.home.currentTime);
  const changeTime = (currentTime) => dispatch(TimeActionCreator.changeTime({ currentTime }));
  return <Home currentTime={currentTime} changeTime={changeTime } />;
}

export { Home };
export default HomeContainer;
