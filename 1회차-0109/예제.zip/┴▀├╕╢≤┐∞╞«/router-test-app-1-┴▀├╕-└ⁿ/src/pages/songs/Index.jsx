import React from 'react';

const Index = () => {
    return (
        <>
            <hr />
            <h3>현재 재생중인 곳 없음</h3>
        </>
    );
};

export default Index;