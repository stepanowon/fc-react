const About = (props) => {
  return (
    <div className="card card-body">
      <h2>About {props.title}</h2>
    </div>
  );
};

export default About;
