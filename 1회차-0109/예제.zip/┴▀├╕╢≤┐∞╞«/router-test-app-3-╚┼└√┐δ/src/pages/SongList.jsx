import { Link, Outlet, useMatch } from "react-router-dom";

const SongList = (props) => {
  const pathMatch = useMatch("/songs/:id");
  let param_id = pathMatch?.params.id ? parseInt(pathMatch.params.id, 10) : -1;

  let list = props.songs.map((song) => {
    return (
      <li key={song.id}
        className={param_id === song.id ? "list-group-item list-group-item-secondary" : "list-group-item"}>
        <Link to={`/songs/${song.id}`} style={{ textDecoration: "none" }}>
          {song.title} ( {song.musician} )
          <span className="float-end badge bg-secondary">
            <i className="fa fa-play"></i>
          </span>
        </Link>
      </li>
    );
  });
  return (
    <div>
      <h2 className="m-5">Song List</h2>
      <ul className="list-group">{list}</ul>
      <Outlet context={{ songs: props.songs }} />
    </div>
  );
};

export default SongList;
