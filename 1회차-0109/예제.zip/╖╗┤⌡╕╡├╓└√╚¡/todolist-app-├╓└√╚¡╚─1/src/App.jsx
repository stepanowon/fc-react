import React, { useCallback, useState } from "react";
import TodoList from "./TodoList";

const App = () => {
  const [todoList, setTodoList] = useState([]);
  const [todo, setTodo] = useState("");

  const addTodo = useCallback((todo) => {
    let newTodoList = [...todoList, { id: new Date().getTime(), todo: todo }];
    setTodoList(newTodoList);
    setTodo("");
  }, [todoList]);

  const deleteTodo = useCallback((id)=> {
    let newTodoList = todoList.filter((item)=>item.id !== id);
    setTodoList(newTodoList);
  }, [todoList]);

  return (
    <div className="boxStyle">
      <input type="text" value={todo} onChange={(e) => setTodo(e.target.value)} />
      <button onClick={() => addTodo(todo)}>Add Todo</button>
      <br />
      <TodoList todoList={todoList} deleteTodo={deleteTodo} />
      <div>todo 개수 : {todoList.length}</div>
    </div>
  );
};

export default App;
