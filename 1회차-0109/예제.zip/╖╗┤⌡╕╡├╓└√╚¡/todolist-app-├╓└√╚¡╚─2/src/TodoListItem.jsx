import React from "react";
import { useDispatch } from "react-redux";
import { TodoActionCreator } from "./redux/TodoStore";

const TodoListItem = React.memo(({ todoListItem, deleteTodo}) => {
  console.log("## TodoListItem");
  return <li>
      {todoListItem.todo} 
      <button onClick={()=>deleteTodo(todoListItem.id)}>삭제</button>
    </li>;
});

const TodoListItemContainer = ({ todoListItem})=> {
  const dispatch = useDispatch();
  const deleteTodo = (id)=>dispatch(TodoActionCreator.deleteTodo({ id }));
  return <TodoListItem todoListItem={todoListItem} deleteTodo={deleteTodo} />
}

export default React.memo(TodoListItemContainer);
