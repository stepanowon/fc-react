import { createAction, createReducer, configureStore } from "@reduxjs/toolkit";

export const TodoActionCreator = {
    addTodo: createAction("addTodo"),
    deleteTodo: createAction("deleteTodo")
}
const initialState = {
    todoList: []
}

export const TodoReducer = createReducer(initialState, (builder)=>{
    builder
        .addCase(TodoActionCreator.addTodo, (state, action)=>{
            state.todoList.push({ id: new Date().getTime(), todo: action.payload.todo})
        })
        .addCase(TodoActionCreator.deleteTodo, (state, action)=>{
            let index = state.todoList.findIndex((item)=>item.id === action.payload.id);
            state.todoList.splice(index,1);
        })
        .addDefaultCase((state)=>state)
})

export const TodoStore = configureStore({ reducer: TodoReducer });




