import React from "react";
import TodoListItem from "./TodoListItem";
import { useDispatch, useSelector } from "react-redux";

const TodoList = React.memo(({ todoList }) => {
  console.log("## TodoList");
  return (
    <ul>
      {todoList.map((todoItem) => (
        <TodoListItem key={todoItem.id} todoListItem={todoItem} />
      ))}
    </ul>
  );
});

const TodoListContainer = ()=> {
  const todoList = useSelector((state)=>state.todoList);
  return <TodoList todoList={todoList} />
}

export default React.memo(TodoListContainer);
