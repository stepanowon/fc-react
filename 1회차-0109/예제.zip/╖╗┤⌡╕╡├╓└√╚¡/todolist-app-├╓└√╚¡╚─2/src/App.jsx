import React, { useState } from "react";
import TodoList from "./TodoList";
import { useDispatch, useSelector } from "react-redux";
import { TodoActionCreator } from "./redux/TodoStore";

const App = ({ todoList, addTodo }) => {
  const [todo, setTodo] = useState("");
  const addTodoHandler = () => {
    addTodo(todo);
    setTodo("");
  }
  return (
    <div className="boxStyle">
      <input type="text" value={todo} onChange={(e) => setTodo(e.target.value)} />
      <button onClick={addTodoHandler}>Add Todo</button>
      <br />
      <TodoList />
    </div>
  );
};

const AppContainer = ()=> {
  const dispatch = useDispatch();
  const todoList = useSelector((state)=>state.todoList);
  const addTodo = (todo)=>dispatch(TodoActionCreator.addTodo({ todo }));

  return <App todoList={todoList} addTodo={addTodo} />
}

export default AppContainer;
