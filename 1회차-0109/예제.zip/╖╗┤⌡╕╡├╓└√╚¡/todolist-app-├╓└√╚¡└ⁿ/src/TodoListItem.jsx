import React from "react";

const TodoListItem = (props) => {
  console.log("## TodoListItem");
  return <li>{props.todoListItem.todo}</li>;
};

export default TodoListItem;
