import React from "react";
import TodoListItem from "./TodoListItem";

const TodoList = (props) => {
  console.log("## TodoList");
  return (
    <ul>
      {props.todoList.map((todoItem) => (
        <TodoListItem key={todoItem.id} todoListItem={todoItem} />
      ))}
    </ul>
  );
};

export default TodoList;
