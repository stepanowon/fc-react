import React, { useState } from 'react';

const App = () => {
  const [html, setHtml] = useState('<script>console.log("hello");</script>');

  return (
      <div>
          HTML 문자열 : <input type="text" value={html} onChange={(e)=>setHtml(e.target.value)} /><br />       
          <hr />
          <div>
            자동 escaping: 
            <div>{html}</div>
          </div>
          <hr />
          <div>
            강제 setInnerHTML : 
            <div dangerouslySetInnerHTML={{__html: html }}></div>
          </div>
      </div>
  );
};

export default App;