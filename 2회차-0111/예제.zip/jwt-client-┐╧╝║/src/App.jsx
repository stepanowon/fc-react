import React from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import { ProtectedRoute } from './AuthProvider';
import AuthButton from './components/AuthButton';

import PublicPage from './pages/PublicPage';
import LoginPage from './pages/LoginPage';
import UserPage from './pages/UserPage';
import AdminPage from './pages/AdminPage';

const App = () => {
    return (
      <Router>
        <div style={{ margin:'10px' }}>
            <div> 
              <span style={{}}>
                <Link to="/">Home</Link>&nbsp; | &nbsp;
                <Link to="/users">Users</Link>&nbsp; | &nbsp;
                <Link to="/admins">관리자페이지</Link> 
                <AuthButton />
              </span>
            </div>
            <hr/>
            <Routes>
                <Route path="/" element={<PublicPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/users" element={ <ProtectedRoute><UserPage /></ProtectedRoute> } />
                <Route path="/admins" element={ <ProtectedRoute><AdminPage /></ProtectedRoute> } />
            </Routes>
        </div>
      </Router>
    );
};
export default App;
