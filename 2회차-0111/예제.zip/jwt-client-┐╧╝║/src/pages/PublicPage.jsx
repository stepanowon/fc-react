import React from 'react';

const PublicPage = () => {
    return (
        <div>
            <h3>Home : 로그인하지 않아도 접근가능한 페이지</h3>
        </div>
    );
};

export default PublicPage;
