import axios from 'axios';
import React, { useState } from 'react';
import { useCookies } from 'react-cookie';
import { useNavigate } from 'react-router';

const Home = () => {
    const [ cookies, setCookie ] = useCookies(["refresh_token", "access_token"]);
    const [RT, setRT] = useState("");
    const [userid, setUserid] = useState("");
    const [password, setPassword] = useState("");

    const navigate = useNavigate();

    const saveCookie = () => {
        let currentTime = new Date();
        currentTime.setHours(currentTime.getHours()+ 24*7)

        setCookie("refresh_token", RT, {
            path:"/", 
            expires: currentTime,
            domain: "test.com",
            //sameSite: "none",
            //httpOnly: true,
            //secure:true,        //https 사용시에만
        })
        navigate("/about");
    }

    const login = async ()=>{
        const response = await axios.post("http://backend.test.com:3000/login", { userid, password });
        if (response.data.status === "success") {
            setRT(response.data.refresh_token);
        }
    }

    return (
        <div>
            <h2>Home</h2>
            <hr />
            RT : <input type="text" value={RT} onChange={(e)=>setRT(e.target.value)} />
            <button onClick={saveCookie}>쿠키 저장</button>
            <hr />
            ID : <input type="text" value={userid} onChange={(e)=>setUserid(e.target.value)}/><br />
            PW : <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)}/><br />
            <button onClick={login}>로그인</button>

        </div>
    );
};

export default Home;