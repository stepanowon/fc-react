import axios from 'axios';
import React, { useState } from 'react';
import { useCookies } from 'react-cookie';

const About = () => {
    const [ cookies, setCookie ] = useCookies(["refresh_token", "access_token"]);
    const [token, setToken] = useState("");
    const tokenUrl = "http://backend.test.com:3000/token";
    //const tokenUrl = "/api/token";

    const readCookie = ()=>{
        setToken(cookies["refresh_token"]);
    }

    const refreshToken = async () => {
        const response = await axios.post(tokenUrl, {}, {
            withCredentials: true
        })    
        console.log(response);
    }

    return (
        <div>
            <h2>About</h2>
            <hr />
            <button onClick={readCookie}>쿠키 읽기</button><br/>
            <div>쿠키 값 : {token}</div>
            <button onClick={refreshToken}>토큰 재발급 요청 : 콘솔 확인</button>
        </div>
    );
};

export default About;