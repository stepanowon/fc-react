import { create } from "zustand"
import { devtools } from "zustand/middleware";
import { immer } from 'zustand/middleware/immer'

const todoStoreFunction = (set) => ({
    todoList: [
        { id: 1, todo: "ES6학습", desc: "설명1", done: false },
        { id: 2, todo: "React학습", desc: "설명2", done: false },
        { id: 3, todo: "ContextAPI 학습", desc: "설명3", done: true },
        { id: 4, todo: "야구경기 관람", desc: "설명4", done: false },
    ],
    addTodo: (todo, desc)=> {
        set((state)=>{
            state.todoList.push({ id: new Date().getTime(), todo, desc, done: false });
        })
    },
    deleteTodo: (id)=>{
        set((state)=>{
            let index = state.todoList.findIndex((todo) => todo.id === id);
            state.todoList.splice(index, 1);
        })
    },
    toggleDone: (id)=> {
        set((state)=>{
            let index = state.todoList.findIndex((todo) => todo.id === id);
            state.todoList[index].done = !state.todoList[index].done;
        })
    },
    updateTodo: (id, todo, desc, done)=> {
        set((state)=>{
            let index = state.todoList.findIndex((todo) => todo.id === id);
            state.todoList[index] = { ...state.todoList[index], todo, desc, done };
        })
    }
})

const a = create()

const useTodoStore3 = create()(
    devtools(
        immer(todoStoreFunction)
    )
);

export default useTodoStore3;