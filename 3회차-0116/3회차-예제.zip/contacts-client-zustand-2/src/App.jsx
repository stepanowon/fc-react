import useContactStore from "./store/useContactStore";
import { useState } from "react";

const App = () => {
  const [name, setName] = useState("");
  const contacts = useContactStore((state)=>state.contacts);
  const isLoading = useContactStore((state)=>state.isLoading);
  const asyncSearchContacts = useContactStore((state)=>state.asyncSearchContacts);

  const search = () => {
    asyncSearchContacts(name, (message)=>{
      alert(message)
    });
    setName("");
  };

  return (
    <div>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button onClick={search}>조회</button>
      <br />
      <ul>
        {contacts.map((item) => {
          return (
            <li key={item.no}>
              {item.name} : {item.tel} : {item.address}{" "}
            </li>
          );
        })}
      </ul>
      {isLoading ? <h3>조회중</h3> : ""}
    </div>
  );
};

export default App;