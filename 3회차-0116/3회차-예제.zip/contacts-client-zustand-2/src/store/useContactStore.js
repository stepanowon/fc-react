import axios from "axios"
import { create } from "zustand";

const BASEURL = "https://contactsvc.bmaster.kro.kr/contacts_long/search/";

const stateCreator = (set)=>({
    contacts : [],
    isLoading : false,
    asyncSearchContacts : async (name, errorCallback)=> {
        set((state)=>({ contacts: [], isLoading: true}));
        try {
            const response = await axios.get(BASEURL + name);
            set((state)=>({ contacts: response.data }));
        } catch (e) {
            errorCallback("에러발생 : " + e.message);
        }
        set((state)=>({ isLoading: false }));
    }
})

const useContactStore = create(stateCreator);

export default useContactStore;
