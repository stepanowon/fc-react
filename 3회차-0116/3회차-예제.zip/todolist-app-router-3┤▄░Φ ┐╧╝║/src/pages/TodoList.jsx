import { Link } from "react-router-dom";
import TodoItem from "./TodoItem";
import { useDispatch, useSelector } from "react-redux";
import { TodoActionCreator } from "../redux/TodoActionCreator";

const TodoList = ({ todoList, deleteTodo, toggleDone }) => {
  let todoItems = todoList.map((item) => {
    return <TodoItem key={item.id} todoItem={item} 
              deleteTodo={deleteTodo} toggleDone={toggleDone} />;
  });
  return (
    <>
      <div className="row">
        <div className="col p-3">
          <Link className="btn btn-primary" to="/todos/add">
            할일 추가
          </Link>
        </div>
      </div>
      <div className="row">
        <div className="col">
          <ul className="list-group">{todoItems}</ul>
        </div>
      </div>
    </>
  );
};

const TodoListContainer = ()=>{
  const dispatch = useDispatch();
  const todoList = useSelector((state)=>state.todos.todoList);
  const toggleDone = (id) => dispatch(TodoActionCreator.toggleDone({id}))
  const deleteTodo = (id) => dispatch(TodoActionCreator.deleteTodo({id}))
  return <TodoList todoList={todoList} deleteTodo={deleteTodo} toggleDone={toggleDone} />
}

export { TodoList }
export default TodoListContainer;
